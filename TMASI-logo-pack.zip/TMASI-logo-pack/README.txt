TMASI LOGO PACK  (15 October 2026)

1-current-logo-files
  The logo files we already had, unchanged. The live site logo, the transparent
  header version, the 2023 purple version, the brand guideline PDF and the crops
  taken from it, and the live favicon. All are raster (pixels), none are vector.

2-vector-svg
  The new vector logo. Sharp at any size, for print, signage, web and video.
  Redrawn from the 2023 master (the sharpest file we have) in the current
  teal colours. The wordmark is Big Noodle Titling, the logo's own font,
  turned into outlines, so no font is needed to open these files.
    horizontal ............ mark left, words right (main logo)
    stacked ............... mark on top, words below
    mark .................. the arch with globe, heartbeat and plane, alone
    wordmark .............. the words alone
  Colour versions:
    (no suffix) ........... full colour, charcoal words, for white backgrounds
    on-dark ............... full colour mark, white words, for navy, black or photos
    black ................. one colour black, for fax, stamps, engraving, one-colour print
    white ................. one colour white, for teal, navy or photo backgrounds
    teal (mark only) ...... one colour TMASI teal #009A9C

3-png
  The same files as PNG with transparent background, at 600, 1200 and 2400 px wide.
  Use these in Word, PowerPoint, email signatures and social posts.

4-favicon-and-app-icons
  favicon.ico, favicon PNGs, apple touch icon (180), Android icons (192, 512),
  a 1080 square for social media profile pictures, and their SVG sources.

5-font
  Big Noodle Titling with its free licence (personal and commercial use).

Colours (from the TMASI brand guideline)
  Teal #009A9C   Medium blue #007AB5   Indigo #0F205C   Words #373A3A

contact-sheet.png shows every version.
Not the original designer's file. When the original vector files arrive, they replace this pack.
