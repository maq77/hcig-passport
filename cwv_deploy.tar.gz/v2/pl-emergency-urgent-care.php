<?php
/* MedPark v2, /pl/opieka-nagla-i-ostre-stany/. Built 2026-09-05.

   Every word comes out of this page's own PL source: the h1, the lead,
   each heading, each card and the call to action. Nothing translated. */
$SITE = 'https://www.medparkhospitals.com';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };
$PAGE_TITLE = 'Całodobowa opieka nagła i ostre stany | MedPark';
$PAGE_DESC  = '24/7 emergency and urgent care at MedPark Hospital. Fast diagnostics, ICU support, ambulance services, and hospital-based treatment in Hurghada, El Quseir and the Red Sea region.';
$PAGE_PATH  = '/pl/opieka-nagla-i-ostre-stany/';
$PAGE_LANG  = 'pl';
$MP_MEDICAL = true;
$MP_CRUMBS  = array(
  'MedPark' => '/pl/',
  'Całodobowa opieka nagła i ostre stany w MedPark' => '/pl/opieka-nagla-i-ostre-stany/',
);
$PAGE_HERO_PRELOAD = '/img/emergenc.jpg';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="svc-page">

  <section class="phero">
    <img class="phero__bg" src="/img/emergenc.jpg" alt="" aria-hidden="true" fetchpriority="high" decoding="async">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <nav class="crumbs" aria-label="Breadcrumb">
        <a href="/pl/">MedPark</a> <span aria-hidden="true">&rsaquo;</span> <span>Całodobowa opieka nagła i ostre stany w MedPark</span>
      </nav>
      <h1>Całodobowa opieka nagła i ostre stany w MedPark</h1>
      <p class="phero__lead">Szpital MedPark zapewnia całodobową opiekę nagłą i leczenie ostrych stanów dla pacjentów, którzy wymagają natychmiastowej pomocy medycznej, szybkiej diagnostyki oraz wsparcia stacjonarnego.</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Zadzwoń teraz</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Kiedy powinieneś się tutaj zgłosić</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-heartbeat" aria-hidden="true"></i><span>Ból w klatce piersiowej</span></li>
        <li class="svc"><i class="fas fa-lungs" aria-hidden="true"></i><span>Problemy z oddychaniem</span></li>
        <li class="svc"><i class="fas fa-bolt" aria-hidden="true"></i><span>Silny ból</span></li>
        <li class="svc"><i class="fas fa-tint" aria-hidden="true"></i><span>Odwodnienie</span></li>
        <li class="svc"><i class="fas fa-user-injured" aria-hidden="true"></i><span>Uraz / kontuzja</span></li>
        <li class="svc"><i class="fas fa-thermometer-half" aria-hidden="true"></i><span>Gorączka i infekcja</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Ostry ból brzucha</span></li>
        <li class="svc"><i class="fas fa-dizzy" aria-hidden="true"></i><span>Słabość / zawroty głowy</span></li>
      </ul>
    </div>
  </section>

  <section class="sec">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Co oferuje Szpital MedPark</h2></div>
      <ul class="feat__grid" data-reveal-stagger role="list">
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Straż Pożarna / Izba Przyjęć</h3>
          <p class="feat__d">Natychmiastowe badanie i leczenie w nagłych przypadkach i stanach zagrażających życiu.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Opieka ostrych stanów</h3>
          <p class="feat__d">Szybkie leczenie urazów, infekcji, odwodnienia oraz nagłych problemów medycznych niezagrażających życiu.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Tomografia komputerowa (CT) i diagnostyka obrazowa</h3>
          <p class="feat__d">Szybka tomografia komputerowa oraz wsparcie diagnostyczne dla precyzyjnych i terminowych decyzji klinicznych.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Oddział intensywnej terapii / Opieka krytyczna</h3>
          <p class="feat__d">Rozszerzona obserwacja i intensywne leczenie pacjentów z ciężkimi stanami medycznymi.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Transport medyczny i karetka</h3>
          <p class="feat__d">Koordynacja transportu ratunkowego i przewozu pacjentów w Hurghadzie, El Quseir oraz całym regionie Morza Czerwonego.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Laboratorium i diagnostyka</h3>
          <p class="feat__d">Kompleksowe badania laboratoryjne i diagnostyczne wspierające szybką diagnozę i leczenie.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Przyjęcie szpitalne</h3>
          <p class="feat__d">Przyjęcie do szpitala i obserwacja pacjenta, gdy wymagana jest rozszerzona opieka lub leczenie.</p>
        </li>
      </ul>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Dla turystów i pacjentów międzynarodowych</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-language" aria-hidden="true"></i><span>Wsparcie wielojęzyczne</span></li>
        <li class="svc"><i class="fas fa-file-medical" aria-hidden="true"></i><span>Wsparcie ubezpieczeniowe</span></li>
        <li class="svc"><i class="fas fa-clock" aria-hidden="true"></i><span>Szybka koordynacja</span></li>
        <li class="svc"><i class="fas fa-hotel" aria-hidden="true"></i><span>Komunikacja z hotelem / transport</span></li>
      </ul>
      <p class="feat__note">Możliwość leczenia bezgotówkowego za pośrednictwem międzynarodowych sieci ubezpieczeniowych i assistance.</p>
    </div>
  </section>

  <section class="sec ctaband">
    <div class="wrap ctaband__inner">
      <h2 class="ctaband__h">Zadzwoń do zespołu ratunkowego MedPark</h2>
      <div class="ctaband__actions">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Zadzwoń teraz</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>

</main>
<?php include __DIR__ . '/_footer.php'; ?>
