<?php
/* MedPark v2: medparkhospital. DRAFT, served only on ?preview=2.

   Rebuilt from scratch 2026-09-05. Every word comes out of C:/Users/maqmo/AppData/Local/Temp/claude/D--Healthcare-international-group/ca4b8781-4744-4dff-94c7-2be283b3c34d/scratchpad/intl/de/medparkhospital.php
   unchanged: the h1, the subtitle, the about paragraph, the nine service
   names, the gallery alt text, the contact rows, the map. The generator
   stops rather than inventing anything it cannot find.

   The page keeps its own assets throughout: its own hero photograph, its
   own video, and its own Google reviews widget id. Nothing is borrowed
   from the other branch or from the home page. */
$SITE = 'https://www.medparkhospitals.com';
$TEL  = '+201222710888';
$TELD = '+20 122 271 0888';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };

$nav = [
  '/' => 'Home', '/about/' => 'About', '/emergency-urgent-care/' => 'Emergency',
  '/services/' => 'Services', '/diagnostics-imaging/' => 'Diagnostics',
  '/news/' => 'News', '/contact-us/' => 'Contact',
];

$PAGE_LANG  = 'de';
$PAGE_PATH  = '/de/medparkhospital.php';
$PAGE_TITLE = 'MedPark Hospital El Quseir | Klinik am Roten Meer';
$PAGE_DESC  = 'MedPark Krankenhaus in El Quseir ist eines der größten multidisziplinären Fachkrankenhäuser der Tertiärversorgung im Gouvernement Rotes Meer. Es bietet ein';
$PAGE_HERO_PRELOAD = '/imaghosp/IMG_4655.webp';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="loc-page">

  <!-- HERO. The page's own photograph. The phone number and the existing
       directions link sit here because somebody unwell on holiday needs
       to reach the hospital before they need to read about it. -->
  <section class="phero">
    <img class="phero__bg" src="/imaghosp/IMG_4655.webp" alt="" aria-hidden="true" fetchpriority="high" decoding="async" width="1410" height="1170">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <h1>MedPark Krankenhaus</h1>
      <p class="phero__lead">Hervorragende Versorgung im Herzen des Roten Meeres</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201210533335">
          <i class="fas fa-phone" aria-hidden="true"></i> +20 121 053 3335</a>
        <a class="btn btn--ghost btn--lg" href="https://www.google.com/maps/dir/?api=1&amp;destination=26.1498769,34.2487632" target="_blank" rel="noopener">
          <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> </a>
      </div>
    </div>
  </section>

  <!-- ABOUT -->
  <section class="sec" id="about">
    <div class="wrap sec__narrow">
      <div class="sec-head" data-reveal><h2>Über das Krankenhaus</h2></div>
      <p class="prose" data-reveal><strong class="texthosp">MedPark Krankenhaus</strong> in El Quseir ist eines der größten multidisziplinären Fachkrankenhäuser der Tertiärversorgung im Gouvernement Rotes Meer. Es bietet ein umfassendes Spektrum an stationären und ambulanten Dienstleistungen, 24/7-Notfallversorgung sowie modernste medizinische, chirurgische und diagnostische Technologien. Unser engagiertes Team aus Ärzten, Pflegekräften und Technikern gewährleistet eine hochwertige Versorgung, die auf Mitgefühl, Respekt und Integrität basiert. Gemeinsam gestalten wir eine stärkere, gesündere Zukunft – retten Leben, verbessern Behandlungsergebnisse und setzen Maßstäbe für die Gesundheitsversorgung im Roten Meer und darüber hinaus.</p>
    </div>
  </section>

  <!-- VIDEO. Two files where the page used to have one: a small silent
       loop behind the button, and the full-quality clip with sound that
       only downloads when somebody presses play. Both fall back to the
       original file if the re-encoded ones are not uploaded yet. The
       loop carries preload=none and does not start until it scrolls
       into view, so it costs nothing to anyone who never reaches it. -->
  <?php
    /* Prefer the re-encoded files, fall back to the original. */
    $mp_v     = '/videos/widget-1';
    $mp_root  = $_SERVER["DOCUMENT_ROOT"];
    $mp_prev  = is_file($mp_root . $mp_v . "-preview.mp4") ? $mp_v . "-preview.mp4" : $mp_v . ".mp4";
    $mp_hq    = is_file($mp_root . $mp_v . "-hq.mp4")      ? $mp_v . "-hq.mp4"      : $mp_v . ".mp4";
  ?>
  <section class="sec sec--dark" id="video">
    <div class="wrap">
      <div class="vshow" data-reveal>
        <video class="vshow__v" muted loop playsinline preload="none"
               data-lazyvideo="<?php echo $e($mp_prev); ?>"
               poster="/videos/widget-1.jpg" aria-hidden="true" tabindex="-1"></video>
        <button type="button" class="vshow__play" data-video-open data-video-fullscreen
                data-video-src="<?php echo $e($mp_hq); ?>"
                aria-label="Watch the video">
          <span class="vshow__ring"><i class="fas fa-play" aria-hidden="true"></i></span>
          <span class="vshow__label">Watch video</span>
        </button>
      </div>
    </div>
  </section>

  <!-- SERVICES. Each name carries its own icon, from the free Font
       Awesome set the site already loads. For a visitor skimming in a
       second language a tooth or a brain lands before the words do. -->
  <section class="sec" id="services">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>angebotene Dienstleistungen</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Allgemeinmedizin &amp; Hausarztpraxis</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Notfall- &amp; Akutversorgung</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Frauenheilkunde</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Männergesundheit</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Psychische Gesundheit &amp; Beratung</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Wellness &amp; Präventivmedizin</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Ästhetik &amp; Hautpflege</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Zahnarztleistungen</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Labor &amp; Diagnostik</span></li>
      </ul>
    </div>
  </section>

  <!-- GALLERY. A vertical marquee: three columns drifting in opposite
       directions, cloned once in JavaScript so the loop is seamless.
       Pauses on hover and focus, and does not run at all under
       prefers-reduced-motion. Replaces the Swiper bundle: a
       render-blocking stylesheet plus a script from unpkg. -->
  <section class="sec sec--tint" id="gallery">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Galerie</h2></div>
      <div class="gal" role="group" aria-label="Galerie">
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/Polarasmy-110.webp" alt="Patientenzimmer" loading="eager" fetchpriority="high" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4651.webp" alt="Operationssaal" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4656.webp" alt="Krankenhaushalle" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-185.webp" alt="Operationssaal" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--up">
          <figure><img src="/imaghosp/IMG_4647.webp" alt="Patientenzimmer" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4650.webp" alt="Mitarbeiterteam" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-182.webp" alt="Patientenzimmer" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/IMG_4653.webp" alt="Labor" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4646.webp" alt="Empfangsbereich" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-183.webp" alt="Labor" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
      </div>
    </div>
  </section>

  <!-- REVIEWS. The existing Elfsight widget, this branch's own id, left
       exactly as it was found. Real Google reviews in the languages the
       patients actually wrote them in are the strongest proof on the
       page, so they sit above the map rather than below it. -->
  <section class="sec sec--tint" id="reviews">
    <div class="wrap wrap--wide">
      <script src="https://static.elfsight.com/platform/platform.js" async></script>
      <div class="elfsight-app-7a31d17b-c9b4-414b-8728-4690aee2f8be" data-elfsight-app-lazy></div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="sec sec--tint" id="contact">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Kontakt &amp; Standort</h2></div>
      <div class="cplace" data-reveal>
        <div class="cplace__map">
          <iframe title="MedPark Krankenhaus" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"
            src="https://maps.google.com/maps?q=26.1498769,34.2487632&amp;z=15&amp;output=embed"></iframe>
        </div>
        <div class="cplace__body">
          <div class="cplace__rows">
            <div class="cplace__row"><i class="fas fa-circle-info" aria-hidden="true"></i>
              <span><b>Adresse</b>Al Owina, El Quseir, Gouvernorat Rotes Meer, Ägypten</span></div>
            <div class="cplace__row"><i class="fas fa-circle-info" aria-hidden="true"></i>
              <span><b>Telefon</b><a href="tel:+201210533335">+20 121 053 3335</a></span></div>
            <div class="cplace__row"><i class="fas fa-circle-info" aria-hidden="true"></i>
              <span><b>E-Mail</b><a href="mailto:info@medparkhospitals.com">info@medparkhospitals.com</a></span></div>
            <div class="cplace__row"><i class="fas fa-circle-info" aria-hidden="true"></i>
              <span><b>Öffnungszeiten</b>Notfall 24/7, Ambulanz 8:00 - 20:00</span></div>
          </div>
          <div class="cplace__cta">
            <a class="btn btn--urgent" href="tel:+201210533335"><i class="fas fa-phone" aria-hidden="true"></i> +20 121 053 3335</a>
            <a class="btn btn--outline" href="https://www.google.com/maps/dir/?api=1&amp;destination=26.1498769,34.2487632" target="_blank" rel="noopener">
              <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> </a>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/_footer.php'; ?>
