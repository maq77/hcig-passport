<?php
/* Shared <head> for every v2 page.

   Extracted from home.php on 2026-09-03 so the inner pages use the same shell
   instead of a copy that drifts. A page sets $PAGE_TITLE and $PAGE_DESC before
   including this; everything else is identical everywhere.

   The rendered output of home.php was byte-compared before and after this
   split, so nothing about the approved page changed. */
if (!isset($PAGE_LANG))  $PAGE_LANG  = 'en';
if (!isset($PAGE_TITLE)) $PAGE_TITLE = 'MedPark Hospitals | 24/7 Emergency Care in Hurghada & El Quseir';
if (!isset($PAGE_DESC))  $PAGE_DESC  = "24/7 emergency and urgent care on Egypt's Red Sea coast. Walk in without an appointment. English, German and Polish spoken. International insurance accepted.";
?>
<?php
/* MedPark v2 homepage. DRAFT, served only on ?preview=2.
   Every fact here is taken from the existing live site or the brand guideline.
   No medical claim, statistic or credential has been invented. */
$SITE = 'https://www.medparkhospitals.com';
$TEL  = '+201222710888';
$TELD = '+20 122 271 0888';
$e = function ($v) { /* decode first: some copy is stored with HTML entities,
   and escaping those again printed &amp;amp; and &amp;auml; in alt and aria text */
  return htmlspecialchars(html_entity_decode((string) $v, ENT_QUOTES, 'UTF-8'),
                          ENT_QUOTES, 'UTF-8'); };

$nav = [
  '/' => 'Home', '/about/' => 'About', '/emergency-urgent-care/' => 'Emergency',
  '/services/' => 'Services', '/diagnostics-imaging/' => 'Diagnostics',
  '/news/' => 'News', '/contact-us/' => 'Contact',
];
?><!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($PAGE_LANG ?? 'en', ENT_QUOTES, 'UTF-8'); ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php /* Kept out of the index only while this is served behind ?preview.
   Once the preview guard is removed from the live page this stops firing and
   the page is indexable. Same rule header-inner.php uses. */ ?>
<?php if (isset($_GET['preview'])): ?>
<meta name="robots" content="noindex,nofollow">
<?php endif; ?>
<title><?php echo $e($PAGE_TITLE); ?></title>
<meta name="description" content="<?php echo $e($PAGE_DESC); ?>">
<?php /* The favicon was a 1500x1500 photograph weighing 85 KB, fetched on
   every page for a 16 pixel slot. These three are 4 KB in total. */ ?>
<link rel="icon" href="/favicon.ico" sizes="32x32">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<?php /* Google Fonts removed 2026-09-02. The guideline specifies Helvetica World
   for paragraph text, which resolves to the system Helvetica stack, and Organo
   for display, which is self-hosted below. Arimo was never a brand face, and
   loading it cost a render-blocking stylesheet plus DNS and TLS to two external
   hosts for a font the guideline does not ask for. */ ?>
<link rel="preload" as="style" href="/css/v2.css?v=<?php echo @filemtime($_SERVER['DOCUMENT_ROOT'].'/css/v2.css'); ?>">
<link rel="stylesheet" href="/css/v2.css?v=<?php echo @filemtime($_SERVER['DOCUMENT_ROOT'].'/css/v2.css'); ?>">
<link rel="stylesheet" href="/css/mp-icons.css?v=<?php echo @filemtime($_SERVER['DOCUMENT_ROOT'].'/css/mp-icons.css'); ?>">
<link rel="preload" href="/fonts/Organo-Regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/fonts/mp-icons-solid.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/fonts/mp-icons-brands.woff2" as="font" type="font/woff2" crossorigin>
<?php
$mp_hero_preload = $PAGE_HERO_PRELOAD ?? '/videos/hero-poster.webp';
if (is_file($_SERVER['DOCUMENT_ROOT'] . $mp_hero_preload)): ?>
<link rel="preload" as="image" href="<?php echo $e($mp_hero_preload); ?>" fetchpriority="high">
<?php endif; ?>
<?php /* GA4. One property, ours.
   G-QSK7TQV4S0 was created by a previous developer and nobody here can reach
   it. It was kept alongside ours in case access was ever recovered, but a
   second property makes Google fetch a second config bundle, which cost
   167 KB on every first visit for data nobody can read. Removed 2026-09-07
   with the owner's agreement. */ ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-LE2B44N7SF"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-LE2B44N7SF');
</script>
<?php
/* ---------------------------------------------------------------------------
   Canonical, language alternates, social tags and structured data.
   Ported from header-inner.php 2026-09-05 so that going live loses nothing.
   --------------------------------------------------------------------------- */
$MP_SITE = 'https://www.medparkhospitals.com';
if (!isset($PAGE_PATH)) $PAGE_PATH = strtok($_SERVER['REQUEST_URI'], '?');
if (!isset($PAGE_LANG)) $PAGE_LANG = 'en';
/* The sharing picture. It used to be logo.JPG, which is 1500x1500. A square
   picture in a large-image card is cropped or refused, and no width or height
   was declared, which is the usual reason a card comes back empty on the
   first scrape: the scraper will not fetch the file to find out. This one is
   1200x630, the size every scraper is built around, and the size is stated
   below so nothing has to be fetched to lay the card out. */
if (!isset($OG_IMAGE))  $OG_IMAGE  = $MP_SITE . '/img/og-medpark.jpg';
if (!isset($OG_IMAGE_W)) $OG_IMAGE_W = 1200;
if (!isset($OG_IMAGE_H)) $OG_IMAGE_H = 630;
if (!isset($OG_IMAGE_ALT)) $OG_IMAGE_ALT = 'MedPark Health Group';
$MP_CANON = $MP_SITE . $PAGE_PATH;
$mpe = function ($v) { /* decode first: some copy is stored with HTML entities,
   and escaping those again printed &amp;amp; and &amp;auml; in alt and aria text */
  return htmlspecialchars(html_entity_decode((string) $v, ENT_QUOTES, 'UTF-8'),
                          ENT_QUOTES, 'UTF-8'); };
?>
<link rel="canonical" href="<?php echo $mpe($MP_CANON); ?>">

<meta property="og:type" content="website">
<meta property="og:site_name" content="MedPark Health Group">
<meta property="og:title" content="<?php echo $mpe($PAGE_TITLE); ?>">
<meta property="og:description" content="<?php echo $mpe($PAGE_DESC); ?>">
<meta property="og:url" content="<?php echo $mpe($MP_CANON); ?>">
<meta property="og:image" content="<?php echo $mpe($OG_IMAGE); ?>">
<meta property="og:image:secure_url" content="<?php echo $mpe($OG_IMAGE); ?>">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="<?php echo (int) $OG_IMAGE_W; ?>">
<meta property="og:image:height" content="<?php echo (int) $OG_IMAGE_H; ?>">
<meta property="og:image:alt" content="<?php echo $mpe($OG_IMAGE_ALT); ?>">
<meta property="og:locale" content="<?php
  echo $PAGE_LANG === 'de' ? 'de_DE' : ($PAGE_LANG === 'pl' ? 'pl_PL' : 'en_US'); ?>">
<?php foreach (array('en_US', 'de_DE', 'pl_PL') as $loc):
        $self = $PAGE_LANG === 'de' ? 'de_DE' : ($PAGE_LANG === 'pl' ? 'pl_PL' : 'en_US');
        if ($loc === $self) continue; ?>
<meta property="og:locale:alternate" content="<?php echo $loc; ?>">
<?php endforeach; ?>
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $mpe($PAGE_TITLE); ?>">
<meta name="twitter:description" content="<?php echo $mpe($PAGE_DESC); ?>">
<meta name="twitter:image" content="<?php echo $mpe($OG_IMAGE); ?>">
<meta name="twitter:image:alt" content="<?php echo $mpe($OG_IMAGE_ALT); ?>">

<?php /* Language alternates, from the same verified table the live pages read,
   so the two versions can never disagree about which page is which. */ ?>
<?php
$mp_hre = $_SERVER['DOCUMENT_ROOT'] . '/hreflang.php';
if (is_file($mp_hre)) { require_once $mp_hre; if (function_exists('mp_hreflang_tags')) mp_hreflang_tags(); }
?>

<?php /* Sitelinks navigation. */ ?>
<?php
$mp_snav = $_SERVER['DOCUMENT_ROOT'] . '/sitenav.php';
if (is_file($mp_snav)) { require_once $mp_snav; if (function_exists('mp_sitenav_tags')) mp_sitenav_tags($PAGE_LANG); }
?>

<?php
/* The page, where it sits, and who published it. Keyed by @id so the
   organisation is declared once and referenced everywhere else.

   This used to be wrapped in `if (isset($MP_CRUMBS))`, which meant the home
   page, having no breadcrumb, published no organisation and no hospital at all.
   The breadcrumb is now the only part that depends on crumbs. Fixed 2026-09-07. */
$mp_items = array();
if (isset($MP_CRUMBS) && is_array($MP_CRUMBS)) {
    $mp_pos = 0;
    foreach ($MP_CRUMBS as $mp_name => $mp_href) {
        $mp_pos++;
        $mp_it = array('@type' => 'ListItem', 'position' => $mp_pos, 'name' => $mp_name);
        if ($mp_href !== '') $mp_it['item'] = $MP_SITE . $mp_href;
        $mp_items[] = $mp_it;
    }
}
if (true) {
    $mp_node = array(
        '@type' => (!empty($MP_MEDICAL) ? 'MedicalWebPage' : 'WebPage'),
        '@id' => $MP_CANON . '#webpage',
        'url' => $MP_CANON,
        'name' => $PAGE_TITLE,
        'description' => $PAGE_DESC,
        'inLanguage' => $PAGE_LANG,
        'isPartOf' => array('@id' => $MP_SITE . '/#website'),
        'about' => array('@id' => $MP_SITE . '/#organization'),
        'publisher' => array('@id' => $MP_SITE . '/#organization'),
    );
    if (isset($MP_MAINENTITY)) $mp_node['mainEntity'] = array('@id' => $MP_MAINENTITY);

    /* Who MedPark is, from the one shared definition every page uses.
       See org-schema.php for why this is not inline any more. */
    $mp_orgfile = $_SERVER['DOCUMENT_ROOT'] . '/org-schema.php';
    $mp_org = is_file($mp_orgfile)
            ? (function () use ($mp_orgfile, $MP_SITE, $PAGE_LANG) {
                  require_once $mp_orgfile;
                  return mp_org_schema($MP_SITE, $PAGE_LANG);
              })()
            : array('@type' => 'MedicalOrganization',
                    '@id' => $MP_SITE . '/#organization',
                    'name' => 'MedPark Health Group',
                    'url' => $MP_SITE . '/',
                    'logo' => $MP_SITE . '/logo.JPG');

    $mp_graph = array(
        $mp_node,
        array('@type' => 'WebSite', '@id' => $MP_SITE . '/#website',
              'url' => $MP_SITE . '/', 'name' => 'MedPark Health Group',
              'inLanguage' => $PAGE_LANG,
              'publisher' => array('@id' => $MP_SITE . '/#organization')),
        $mp_org,
    );

    /* A breadcrumb only makes sense where there is a trail. The home page has
       none, and an empty BreadcrumbList is an error, not an omission. */
    if ($mp_items) {
        $mp_graph[] = array('@type' => 'BreadcrumbList',
                            '@id' => $MP_CANON . '#breadcrumb',
                            'itemListElement' => $mp_items);
    }
    if (!empty($MP_EXTRA_NODES) && is_array($MP_EXTRA_NODES)) {
        foreach ($MP_EXTRA_NODES as $mp_x) $mp_graph[] = $mp_x;
    }
    echo '<script type="application/ld+json">'
       . json_encode(array('@context' => 'https://schema.org', '@graph' => $mp_graph),
                     JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
       . "</script>\n";
}
</head>
