<?php /* Real homepage sections, preserved from index.php for the v2 draft.
   Content, images, cards and news are the client's own and are carried over
   unchanged. v2.css restyles them; nothing here is rewritten. */ ?>
<section data-reveal id="about" class="med-section med-light-bg">
  <div class="med-container">
    <h2>Thousands Trust Us. We Treat Each Life Like the Only One.</h2>

    <div class="med-hospitals-grid">
      <!-- HURGHADA -->
      <div class="med-hospital-card">
        <a class="med-hospital-link" href="healthhub.php"
           aria-label="MedPark Health Hub, Hurghada. Learn more">
          <div class="med-hospital-image-wrapper">
            <img src="hospital-hurghada.webp" alt="MedPark Health Hub in Hurghada" loading="lazy" decoding="async" width="1600" height="1067">
            <div class="med-hospital-overlay">
              <h3>MedPark Health Hub, Hurghada</h3>
              <p>
                is a cutting-edge, multidisciplinary medical center designed to meet the modern needs of healthcare.
              </p>
              <span class="med-btn-small">Learn More</span>
            </div>
          </div>
        </a>
      </div>

      <!-- EL QUSEIR -->
      <div class="med-hospital-card">
        <a class="med-hospital-link" href="medparkhospital.php"
           aria-label="MedPark Hospital, El Quseir. Learn more">
          <div class="med-hospital-image-wrapper">
            <img src="Polarasmy-106.webp" alt="MedPark Hospital in El Quseir" loading="lazy" decoding="async" width="1600" height="1066">
            <div class="med-hospital-overlay">
              <h3>MedPark Hospital, El Quseir</h3>
              <p>
                is one of the largest multi-disciplinary specialty tertiary care hospitals in the Red Sea Governorate.
              </p>
              <span class="med-btn-small">Learn More</span>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>


<section data-reveal id="wellness-packages" class="med-section med-wellness-packages">
  <div class="med-container">

    <h2 class="center">
      NEW at MedPark Hospital
    </h2>

    <p class="med-wellness-text center">
      Turn your vacation into a health & wellness upgrade.<br>
      Discover our personalized check-up and wellness packages.
    </p>

    <div class="med-packages-wrapper">

      <button class="med-packages-nav prev" aria-label="Previous">
        ‹
      </button>

      <div class="med-packages-carousel">
          
                  <div class="med-package-card">
          <img src="/img/IMG_7044.webp" alt="Page 01" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_01_Image_0001.webp" alt="Page 01" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_02_Image_0001.webp" alt="Page 02" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_03_Image_0001.webp" alt="Page 03" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_04_Image_0001.webp" alt="Page 04" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_05_Image_0001.webp" alt="Page 05" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_06_Image_0001.webp" alt="Page 06" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_07_Image_0001.webp" alt="Page 07" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_08_Image_0001.webp" alt="Page 08" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_09_Image_0001.webp" alt="Page 09" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_10_Image_0001.webp" alt="Page 10" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_11_Image_0001.webp" alt="Page 11" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_12_Image_0001.webp" alt="Page 12" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_13_Image_0001.webp" alt="Page 13" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_14_Image_0001.webp" alt="Page 14" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_15_Image_0001.webp" alt="Page 15" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_16_Image_0001.webp" alt="Page 16" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_17_Image_0001.webp" alt="Page 17" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_18_Image_0001.webp" alt="Page 18" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_19_Image_0001.webp" alt="Page 19" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

        <div class="med-package-card">
          <img src="/img/Prices_Page_20_Image_0001.webp" alt="Page 20" class="zoomable-image" loading="lazy" decoding="async" width="1743" height="2472">
        </div>

      </div>

      <button class="med-packages-nav next" aria-label="Next">
        ›
      </button>

    </div>
  </div>

  <!-- POPUP -->
  <div class="med-image-popup" id="medImagePopup">
    <span class="med-popup-close">&times;</span>
    <img class="med-popup-img" id="medPopupImg" src="" alt="" loading="lazy" decoding="async">
  </div>

</section>


<style>
.med-wellness-packages {
  padding: 80px 0;
  background: #fff;
}

.med-wellness-text {
  max-width: 760px;
  margin: 20px auto 50px;
  font-size: 18px;
  line-height: 1.6;
  color: #555;
  text-align: center;
}

.med-packages-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  gap: 20px;
}

.med-packages-carousel {
  display: flex;
  gap: 20px;
  overflow-x: auto;
  scroll-behavior: smooth;
  scrollbar-width: none;
  width: 100%;
  padding: 10px 0;
}

.med-packages-carousel::-webkit-scrollbar {
  display: none;
}

.med-package-card {
  flex: 0 0 calc(20% - 16px);
  border-radius: 20px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 10px 30px rgba(0,0,0,0.08);
  transition: 0.3s ease;
}

.med-package-card:hover {
  transform: translateY(-5px);
}

.med-package-card img {
  width: 100%;
  height: auto;
  display: block;
}

.zoomable-image {
  cursor: zoom-in;
}

.med-packages-nav {
  width: 52px;
  height: 52px;
  border: none;
  border-radius: 50%;
  background: #00a6a6;
  color: #fff;
  font-size: 32px;
  cursor: pointer;
  flex-shrink: 0;
  transition: 0.3s;
}

.med-packages-nav:hover {
  background: #008b8b;
}

/* POPUP */

.med-image-popup {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.92);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  opacity: 0;
  visibility: hidden;
  transition: 0.3s;
  padding: 40px;
}

@media (max-width: 768px) {

  .med-packages-carousel {
    scroll-snap-type: x mandatory;
  }

  .med-package-card {
    flex: 0 0 100%;
    scroll-snap-align: center;
  }

}

.med-image-popup.active {
  opacity: 1;
  visibility: visible;
}

.med-popup-img {
  max-width: 95%;
  max-height: 95vh;
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  animation: popupZoom 0.3s ease;
}

@keyframes popupZoom {
  from {
    transform: scale(0.85);
    opacity: 0;
  }
  to {
    transform: scale(1);
    opacity: 1;
  }
}

.med-popup-close {
  position: absolute;
  top: 20px;
  right: 30px;
  color: #fff;
  font-size: 50px;
  cursor: pointer;
  line-height: 1;
  z-index: 10000;
}

@media (max-width: 1200px) {
  .med-package-card {
    flex: 0 0 calc(25% - 15px);
  }
}

@media (max-width: 992px) {
  .med-package-card {
    flex: 0 0 calc(33.333% - 14px);
  }
}

@media (max-width: 768px) {

  .med-package-card {
    flex: 0 0 calc(50% - 10px);
  }

  .med-packages-nav {
    width: 42px;
    height: 42px;
    font-size: 26px;
  }

  .med-wellness-text {
    font-size: 16px;
  }

  .med-image-popup {
    padding: 20px;
  }

  .med-popup-close {
    top: 10px;
    right: 20px;
    font-size: 40px;
  }
}

.med-wellness-packages .center {
  text-align: center;
}

.med-wellness-packages h2 {
  position: relative;
  display: inline-block;
  margin: 0 auto;
  padding: 14px 34px;
  border-radius: 60px;
  background: linear-gradient(135deg, #00a6a6, #00cfcf);
  color: #fff;
  font-weight: 700;
  letter-spacing: 0.5px;
  box-shadow: 0 0 0 rgba(0, 166, 166, 0.7);
  animation: pulseGlow 2s infinite;
}

@keyframes pulseGlow {

  0% {
    transform: scale(1);
    box-shadow:
      0 0 0 0 rgba(0, 166, 166, 0.7),
      0 10px 30px rgba(0,0,0,0.12);
  }

  50% {
    transform: scale(1.04);
    box-shadow:
      0 0 0 18px rgba(0, 166, 166, 0),
      0 14px 40px rgba(0,0,0,0.16);
  }

  100% {
    transform: scale(1);
    box-shadow:
      0 0 0 0 rgba(0, 166, 166, 0),
      0 10px 30px rgba(0,0,0,0.12);
  }
}

@media (max-width: 480px) {

  .med-package-card {
    flex: 0 0 100%;
  }

}
</style>


<script>
document.addEventListener("DOMContentLoaded", function () {

  const carousel = document.querySelector(".med-packages-carousel");
  const prevBtn = document.querySelector(".med-packages-nav.prev");
  const nextBtn = document.querySelector(".med-packages-nav.next");

  function getScrollAmount() {
    const card = document.querySelector(".med-package-card");

    if (!card) return 300;

    const gap = 20;

    return card.offsetWidth + gap;
  }

  nextBtn.addEventListener("click", () => {
    carousel.scrollBy({
      left: getScrollAmount(),
      behavior: "smooth"
    });
  });

  prevBtn.addEventListener("click", () => {
    carousel.scrollBy({
      left: -getScrollAmount(),
      behavior: "smooth"
    });
  });

  // IMAGE POPUP

  const popup = document.getElementById("medImagePopup");
  const popupImg = document.getElementById("medPopupImg");
  const closeBtn = document.querySelector(".med-popup-close");

  document.querySelectorAll(".zoomable-image").forEach(img => {

    img.addEventListener("click", () => {
      popup.classList.add("active");
      popupImg.src = img.src;
    });

  });

  closeBtn.addEventListener("click", () => {
    popup.classList.remove("active");
  });

  popup.addEventListener("click", (e) => {
    if (e.target === popup) {
      popup.classList.remove("active");
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      popup.classList.remove("active");
    }
  });

});
</script>


  <section data-reveal class="emergency-section">
  <div class="container">

    <div class="emergency-content">
      <h2 class="emergency-title">24/7 Emergency & Urgent Care</h2>

      <p class="emergency-text">
        When immediate medical attention is needed, MedPark&nbsp;Hospital is ready 24/7.<br>
        Our emergency and urgent care services support patients with fast access to
        medical evaluation, diagnostics, ambulance coordination, and hospital-level treatment.
      </p>
    </div>

    <!-- ICON STRIP -->
    <div class="emergency-features">

<div class="feature-item">
  <i class="fas fa-hospital"></i>
  <span>Emergency Department</span>
</div>

<div class="feature-item">
  <i class="fas fa-briefcase-medical"></i>
  <span>Urgent Care</span>
</div>

<div class="feature-item">
  <i class="fas fa-x-ray"></i>
  <span>CT Scan</span>
</div>

<div class="feature-item">
  <i class="fas fa-procedures"></i>
  <span>ICU</span>
</div>

<div class="feature-item">
  <i class="fas fa-ambulance"></i>
  <span>Ambulance Support</span>
</div>

<div class="feature-item">
  <i class="fas fa-vials"></i>
  <span>Hospital Diagnostics</span>
</div>

    </div>

    <div class="emergency-cta">
      <a href="/emergency-urgent-care/" class="emergency-btn">
        Learn More About Emergency Care
      </a>
    </div>

  </div>
</section>  

      
<!--<div id="operation-hours">
  <div class="med-container">
    <div class="med-hours-box">
      <div class="med-hours-icon">
        <img src="clokc.webp" alt="24/7 Clock Icon" / loading="lazy" decoding="async">
      </div>
      
      <div class="med-hours-content">
        <h3>24/7 Service</h3>
        <p>
          We operate 24/7, providing emergency care, urgent care, diagnostics, and ambulance-supported medical access whenever needed.
        </p>
      </div>
    </div>
  </div>
</div> -->

      
      

<section data-reveal id="comprehensive-care" class="med-section">
  <div class="med-container">

    <div class="med-features">
      <div class="med-feature">
        <i class="fas fa-stethoscope"></i>
        <div class="med-feature-text">
          <h4>Qualified Doctors</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-ambulance"></i>
        <div class="med-feature-text">
          <h4>Emergency Services</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-flask"></i>
        <div class="med-feature-text">
          <h4>Accurate Testing</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-car"></i>
        <div class="med-feature-text">
          <h4>Fast Ambulance</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-user-md"></i>
        <div class="med-feature-text">
          <h4>24/7 Medical Support</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-microscope"></i>
        <div class="med-feature-text">
          <h4>Modern Equipment</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-language"></i>
        <div class="med-feature-text">
          <h4>Multilingual Staff</h4>
        </div>
      </div>

      <div class="med-feature">
        <i class="fas fa-file-medical"></i>
        <div class="med-feature-text">
          <h4>Insurance Assistance</h4>
        </div>
      </div>
      
      <div class="med-feature">
  <i class="fas fa-x-ray"></i>
  <div class="med-feature-text">
    <h4>CT Scan</h4>
  </div>
</div>

<div class="med-feature">
  <i class="fas fa-bed-pulse"></i>
  <div class="med-feature-text">
    <h4>ICU Support</h4>
  </div>
</div>

<div class="med-feature">
  <i class="fas fa-hospital"></i>
  <div class="med-feature-text">
    <h4>Hospital-Based Emergency Response</h4>
  </div>
</div>
    </div>

  </div>
</section>


<section data-reveal class="capabilities-section">
  <div class="med-container">

    <div class="capabilities-header">
      <h2 class="capabilities-title">Advanced Hospital Capabilities</h2>
      <p class="capabilities-subtitle">
        Hospital-based care supported by modern diagnostics and critical care infrastructure.
      </p>
    </div>

    <div class="capabilities-grid">

      <a href="/emergency-urgent-care#emergency-department" class="capability-card">
       
        <span class="capability-card__ico"><i class="fas fa-hospital" aria-hidden="true"></i></span>
        <h4><span class="accent">Emergency Department</span></h4>
      </a>

      <a href="/emergency-urgent-care#urgent-care" class="capability-card">
    
        <span class="capability-card__ico"><i class="fas fa-stethoscope" aria-hidden="true"></i></span>
        <h4><span class="accent">Urgent Care</span></h4>
      </a>

      <a href="/emergency-urgent-care#diagnostics" class="capability-card">
       
        <span class="capability-card__ico"><i class="fas fa-x-ray" aria-hidden="true"></i></span>
        <h4><span class="accent">CT Scan & Laboratory Diagnostics</span></h4>
      </a>

      <a href="/emergency-urgent-care#icu" class="capability-card">
     
        <span class="capability-card__ico"><i class="fas fa-heart-pulse" aria-hidden="true"></i></span>
        <h4><span class="accent">ICU / Critical Care</span></h4>
      </a>

      <a href="/emergency-urgent-care#ambulance" class="capability-card">
       
        <span class="capability-card__ico"><i class="fas fa-truck-medical" aria-hidden="true"></i></span>
        <h4><span class="accent">Ambulance Support</span></h4>
      </a>

      <a href="/emergency-urgent-care#inpatient" class="capability-card">
        
        <span class="capability-card__ico"><i class="fas fa-bed-pulse" aria-hidden="true"></i></span>
        <h4><span class="accent">Inpatient & Surgical Support</span></h4>
      </a>

    </div>

  </div>
</section>

      
   

   
      
      
<section data-reveal id="appointment" class="med-section med-light-bg">
  <div class="med-container">
    <div class="appointment-content">
      
      <div class="appointment-text">
        <h2>
          Plan Your Medical Journey with MEDPARK HEALTH GROUP
        </h2>

        <p class="appointment-info">
          Discover world-class medical care in Egypt, designed for international patients. Whether you’re looking for specialized treatment, surgery, or wellness recovery, our international patient coordinators are ready to support you every step of the way — from your first message to your full recovery.<br><br>
        </p>
      </div>

      <div class="appointment-form">
<?php /* The form itself lives in a popup in home.php, opened by any element
   carrying data-apt-open: this button, and the Book Appointment buttons in
   the header and the mobile menu. One form, three ways in. */ ?>
        <button type="button" class="btn btn--urgent btn--lg" data-apt-open>
          <i class="fas fa-calendar-check" aria-hidden="true"></i> Book an appointment
        </button>
      </div>

    </div>
  </div>
</section>


      <script>
var mpAptForm = document.getElementById("appointment-form");
if (mpAptForm) mpAptForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);

  fetch("send.php", {
    method: "POST",
    body: formData,
  })
    .then((res) => res.text())
    .then((text) => {
      if (text.trim() === "success") {
        showModal("Your appointment request has been sent!");
        form.reset();
        document.querySelectorAll(".hospital-tab").forEach(tab => tab.classList.remove("active"));
        document.getElementById("hospital1-tab").classList.add("active");
        document.getElementById("hospital").value = "hospital1";
      } else {
        showModal("Error sending your request. Please try again.");
      }
    })
    .catch(() => {
      showModal("Something went wrong. Please try again.");
    });
});

// Tabs logic
document.querySelectorAll(".hospital-tab").forEach((tab) => {
  tab.addEventListener("click", function () {
    document.querySelectorAll(".hospital-tab").forEach((t) => t.classList.remove("active"));
    this.classList.add("active");
    document.getElementById("hospital").value = this.dataset.hospital;
  });
});

// Simple modal
function showModal(message) {
  let modal = document.getElementById("appointmentModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "appointmentModal";
    modal.className = "modal";
    modal.innerHTML = `
      <div class="modal-content">
        <span class="close" onclick="document.getElementById('appointmentModal').style.display='none'">&times;</span>
        <p id="modalMessage">${message}</p>
      </div>`;
    document.body.appendChild(modal);
  } else {
    document.getElementById("modalMessage").textContent = message;
  }
  modal.style.display = "flex";
}

// Закрытие по клику вне модалки
window.onclick = function (e) {
  const modal = document.getElementById("appointmentModal");
  if (e.target === modal) {
    modal.style.display = "none";
  }
};
</script>

<style>
.modal {
  display: none; position: fixed; z-index: 9999;
  left: 0; top: 0; width: 100%; height: 100%;
  background-color: rgba(0,0,0,0.5);
  justify-content: center; align-items: center;
}
.modal-content {
  background: #fff; padding: 20px 30px;
  border-radius: 10px; text-align: center;
  position: relative; max-width: 400px;
}
.modal .close {
  position: absolute; right: 15px; top: 10px;
  font-size: 20px; cursor: pointer;
}
</style>

      
      
      
<section data-reveal id="services" class="med-section">
  <div class="med-container">
    <h2>Medical Services</h2>

    <div class="med-services-grid">
        
        
<div class="med-service emergency-highlight">
  <span class="service-badge">Most Requested</span>

  <img src="IMG_4373.webp" alt="Emergency & Urgent Care" class="service-bg" loading="lazy" decoding="async">

  <a href="/services/" class="service-overlay">
    <h3>Emergency & Urgent Care</h3>
    <div class="service-description">
      24/7 emergency and urgent medical support when every second matters.
    </div>
  </a>
</div>

      <!-- 1 -->
      <div class="med-service">
        <img src="photo_2025-05-27_15-29-03.webp" alt="General Medicine & Family Practice" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>General Medicine & Family Practice</h3>
          <div class="service-description">Your first point of contact for everyday healthcare.</div>
        </a>
      </div>

      <!-- 2 -->
      <div class="med-service">
        <img src="../IMG_4370.webp" alt="Specialty Consultations" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Specialty Consultations</h3>
          <div class="service-description">Expert care from leading medical specialists.</div>
        </a>
      </div>



      <!-- 4 -->
      <div class="med-service">
        <img src="../IMG_4378.webp" alt="Dental Services" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Dental Services</h3>
          <div class="service-description">Comprehensive care for a healthy smile.</div>
        </a>
      </div>

      <!-- 5 -->
      <div class="med-service">
        <img src="../IMG_4382.webp" alt="Women’s Health" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Women’s Health</h3>
          <div class="service-description">Specialized care tailored to women’s needs.</div>
        </a>
      </div>

      <!-- 6 -->
      <div class="med-service">
        <img src="../IMG_4383.webp" alt="Men’s Health" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Men’s Health</h3>
          <div class="service-description">Focused healthcare solutions for men.</div>
        </a>
      </div>

      <!-- 7 -->
      <div class="med-service">
        <img src="../photo_2025-05-27_15-54-38.webp" alt="Mental Health & Counseling" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Mental Health & Counseling</h3>
          <div class="service-description">Professional support for emotional well-being.</div>
        </a>
      </div>

      <!-- 8 -->
      <div class="med-service">
        <img src="../IMG_4391.webp" alt="Wellness & Preventive Medicine" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Wellness & Preventive Medicine</h3>
          <div class="service-description">Proactive care to keep you healthy.</div>
        </a>
      </div>

      <!-- 9 -->
      <div class="med-service">
        <img src="../IMG_4395.webp" alt="Aesthetics & Skin Care" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Aesthetics & Skin Care</h3>
          <div class="service-description">Advanced treatments for confident skin.</div>
        </a>
      </div>

      <!-- 10 -->
      <div class="med-service">
        <img src="../IMG_4400.webp" alt="Rehabilitation & Physiotherapy" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Rehabilitation & Physiotherapy</h3>
          <div class="service-description">Restore mobility. Regain independence.</div>
        </a>
      </div>

      <!-- 11 -->
      <div class="med-service">
        <img src="../IMG_4401.webp" alt="Laboratory & Diagnostic Services" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Laboratory & Diagnostic Services</h3>
          <div class="service-description">Fast, precise and reliable diagnostics.</div>
        </a>
      </div>

      <!-- 12 -->
      <div class="med-service">
        <img src="../IMG_4404.webp" alt="Medical Tourism Services" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Medical Tourism Services</h3>
          <div class="service-description">Complete support for your medical journey.</div>
        </a>
      </div>

      <!-- 13 -->
      <div class="med-service">
        <img src="../IMG_4406.webp" alt="Corporate & B2B Health Services" class="service-bg" loading="lazy" decoding="async">
        <a href="/services/" class="service-overlay">
          <h3>Corporate & B2B Health Services</h3>
          <div class="service-description">Customized healthcare solutions for businesses.</div>
        </a>
      </div>

    </div>
  </div>
</section>


   <section class="mp-pack" id="packages" data-reveal>
  <div class="wrap">
    <div class="mp-pack__head">
      <span class="eyebrow">For travellers</span>
      <h2>MedPark Hospital Packages for Travelers</h2>
      <p>MedPark Hospital offers a range of medical packages designed for travelers visiting
         Hurghada, El Quseir, and the Red Sea region. These packages include dental care,
         aesthetic treatments, diagnostics, and medical services tailored for international patients.</p>
    </div>

    <ul class="mp-pack__grid" role="list" data-reveal-stagger>
      <li class="mp-pack__card">
        <span class="mp-pack__ico"><i class="fas fa-tooth" aria-hidden="true"></i></span>
        <h3>Dental Care</h3>
      </li>
      <li class="mp-pack__card">
        <span class="mp-pack__ico"><i class="fas fa-spa" aria-hidden="true"></i></span>
        <h3>Aesthetic Treatments</h3>
      </li>
      <li class="mp-pack__card">
        <span class="mp-pack__ico"><i class="fas fa-stethoscope" aria-hidden="true"></i></span>
        <h3>Diagnostics &amp; Check-ups</h3>
      </li>
      <li class="mp-pack__card">
        <span class="mp-pack__ico"><i class="fas fa-user-doctor" aria-hidden="true"></i></span>
        <h3>Medical Treatments</h3>
      </li>
    </ul>

    <div class="mp-pack__cta">
      <a href="/medpark-packages/" class="btn btn--urgent btn--lg">
        <i class="fas fa-arrow-right" aria-hidden="true"></i> Explore MedPark Hospital Packages
      </a>
      <p class="mp-pack__note">Designed for international patients and tourists.</p>
    </div>
  </div>
</section>


<section class="mp-ins" id="insurance" data-reveal>
  <div class="wrap mp-ins__inner">
    <span class="mp-ins__icon" aria-hidden="true"><i class="fas fa-shield-heart"></i></span>
    <h2>International Insurance &amp; Assistance Partners</h2>
    <p>
      MedPark Hospital works with major international insurance companies and assistance
      networks to provide cashless emergency, urgent care, and hospital-based medical
      services for travelers and international patients.
    </p>
    <p>
      Our medical teams support patients across Hurghada, El Quseir, and the Red Sea region,
      ensuring fast access to diagnostics, hospital care, and coordinated medical support.
    </p>
  </div>
</section>

      
      
<section class="mp-help" id="help-now" data-reveal>
  <div class="wrap mp-help__inner">
    <span class="eyebrow">Available 24 hours</span>
    <h2>Need Help Now?</h2>
    <p class="mp-help__lead">For emergency situations, urgent medical needs, and hospital-based
      diagnostics, contact MedPark Hospital immediately. Our medical teams in Hurghada,
      El Quseir, and across the Red Sea region are available 24/7.</p>

    <a class="mp-help__num" href="tel:+201222710888">
      <span>Emergency Hotline</span>
      <strong>+20 122 271 0888</strong>
    </a>

    <div class="mp-help__actions">
      <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
        <i class="fas fa-phone" aria-hidden="true"></i> Call Now
      </a>
      <a class="btn btn--ghost btn--lg" href="#locations">
        <i class="fas fa-location-dot" aria-hidden="true"></i> View Locations
      </a>
    </div>
  </div>
</section>
