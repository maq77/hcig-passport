<?php
/* MedPark v2: healthhub. DRAFT, served only on ?preview=2.

   Rebuilt from scratch 2026-09-05. Every word comes out of healthhub.php
   unchanged: the h1, the subtitle, the about paragraph, the nine service
   names, the gallery alt text, the contact rows, the map. The generator
   stops rather than inventing anything it cannot find.

   The page keeps its own assets throughout: its own hero photograph, its
   own video, and its own Google reviews widget id. Nothing is borrowed
   from the other branch or from the home page. */
$SITE = 'https://www.medparkhospitals.com';
$TEL  = '+201222710888';
$TELD = '+20 122 271 0888';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };

$nav = [
  '/' => 'Home', '/about/' => 'About', '/emergency-urgent-care/' => 'Emergency',
  '/services/' => 'Services', '/diagnostics-imaging/' => 'Diagnostics',
  '/news/' => 'News', '/contact-us/' => 'Contact',
];

$PAGE_TITLE = 'Hospital in Hurghada & Sahl Hasheesh | MedPark Health Hub';
$PAGE_DESC  = 'MedPark Health Hub on Sahl Hasheesh Road, Hurghada: 24/7 walk-in urgent care, diagnostics and dental. English, German and Polish spoken.';
$PAGE_PATH  = '/healthhub.php';
$PAGE_LANG  = 'en';
$PAGE_HERO_PRELOAD = '/imaghosp/IMG_0393.webp';
$MP_CRUMBS  = array(
  'Home' => '/',
  'MedPark Health Hub' => '/healthhub.php',
);
$MP_MEDICAL = true;
$MP_MAINENTITY = 'https://www.medparkhospitals.com/healthhub.php#hospital';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="loc-page">

  <!-- HERO. The page's own photograph. The phone number and the existing
       directions link sit here because somebody unwell on holiday needs
       to reach the hospital before they need to read about it. -->
  <section class="phero">
    <img class="phero__bg" src="/imaghosp/IMG_0393.webp" alt="" aria-hidden="true" fetchpriority="high" decoding="async">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <h1>MedPark Health Hub Hurghada</h1>
      <p class="phero__lead">Exceptional Care in the Heart of the Red Sea</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201222289383">
          <i class="fas fa-phone" aria-hidden="true"></i> +20 122 228 9383</a>
        <a class="btn btn--ghost btn--lg" href="https://www.google.com/maps/dir/?api=1&amp;destination=27.0794164,33.8596514" target="_blank" rel="noopener">
          <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> Get directions</a>
      </div>
    </div>
  </section>

  <!-- AT A GLANCE. The same address and hours as the contact section,
       surfaced where somebody deciding whether to travel will look. -->
  <section class="glance">
    <div class="wrap">
      <div class="glance__card">
        <div class="glance__item">
          <i class="fas fa-location-dot" aria-hidden="true"></i>
          <div class="glance__text">
            <b>Address</b>
            <a href="https://maps.google.com/?cid=8921907815233210791" target="_blank" rel="noopener">Sahl Hasheesh Road, Hurghada, Red Sea
              <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i></a>
          </div>
        </div>
        <div class="glance__item">
          <i class="fas fa-clock" aria-hidden="true"></i>
          <div class="glance__text">
            <b>Working Hours</b>
            <span>24/7 Emergency, 8:00 - 20:00 Outpatient</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ABOUT -->
  <section class="sec" id="about">
    <div class="wrap sec__narrow">
      <div class="sec-head" data-reveal><h2>About the Hospital</h2></div>
      <p class="prose" data-reveal><strong class="texthosp">MedPark Health Hub</strong> in Hurghada is a cutting-edge, multidisciplinary medical center designed to meet the modern needs of healthcare. It offers advanced diagnostic capabilities with a personal in-house laboratory, X-ray, and scanning services, alongside a fully equipped surgical department, dental and aesthetic medicine, and 24/7 emergency care supported by ambulance services. As part of our expanding role in medical tourism, the Hub is a trusted destination for patients from around the world seeking exceptional care in a relaxing coastal environment.</p>
    </div>
  </section>

  <!-- VIDEO. Two files where the page used to have one: a small silent
       loop behind the button, and the full-quality clip with sound that
       only downloads when somebody presses play. Both fall back to the
       original file if the re-encoded ones are not uploaded yet. The
       loop carries preload=none and does not start until it scrolls
       into view, so it costs nothing to anyone who never reaches it. -->
  <?php
    /* Prefer the re-encoded files, fall back to the original. */
    $mp_v     = '/videos/widget-2';
    $mp_root  = $_SERVER["DOCUMENT_ROOT"];
    $mp_prev  = is_file($mp_root . $mp_v . "-preview.mp4") ? $mp_v . "-preview.mp4" : $mp_v . ".mp4";
    $mp_hq    = is_file($mp_root . $mp_v . "-hq.mp4")      ? $mp_v . "-hq.mp4"      : $mp_v . ".mp4";
  ?>
  <section class="sec sec--dark" id="video">
    <div class="wrap">
      <div class="vshow" data-reveal>
        <video class="vshow__v" muted loop playsinline preload="none"
               data-lazyvideo="<?php echo $e($mp_prev); ?>"
               poster="/videos/widget-2.jpg" aria-hidden="true" tabindex="-1"></video>
        <button type="button" class="vshow__play" data-video-open data-video-fullscreen
                data-video-src="<?php echo $e($mp_hq); ?>"
                aria-label="Watch the video">
          <span class="vshow__ring"><i class="fas fa-play" aria-hidden="true"></i></span>
          <span class="vshow__label">Watch video</span>
        </button>
      </div>
    </div>
  </section>

  <!-- SERVICES. Each name carries its own icon, from the free Font
       Awesome set the site already loads. For a visitor skimming in a
       second language a tooth or a brain lands before the words do. -->
  <section class="sec" id="services">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Services Offered</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-user-doctor" aria-hidden="true"></i><span>General &amp; Family Medicine</span></li>
        <li class="svc"><i class="fas fa-truck-medical" aria-hidden="true"></i><span>Emergency &amp; Urgent Care</span></li>
        <li class="svc"><i class="fas fa-person-dress" aria-hidden="true"></i><span>Women’s Health</span></li>
        <li class="svc"><i class="fas fa-person" aria-hidden="true"></i><span>Men’s Health</span></li>
        <li class="svc"><i class="fas fa-brain" aria-hidden="true"></i><span>Mental Health &amp; Counseling</span></li>
        <li class="svc"><i class="fas fa-shield-heart" aria-hidden="true"></i><span>Wellness &amp; Preventive Medicine</span></li>
        <li class="svc"><i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i><span>Aesthetics &amp; Skin Care</span></li>
        <li class="svc"><i class="fas fa-tooth" aria-hidden="true"></i><span>Dental Services</span></li>
        <li class="svc"><i class="fas fa-flask-vial" aria-hidden="true"></i><span>Laboratory &amp; Diagnostics</span></li>
      </ul>
    </div>
  </section>

  <!-- GALLERY. A vertical marquee: three columns drifting in opposite
       directions, cloned once in JavaScript so the loop is seamless.
       Pauses on hover and focus, and does not run at all under
       prefers-reduced-motion. Replaces the Swiper bundle: a
       render-blocking stylesheet plus a script from unpkg. -->
  <section class="sec sec--tint" id="gallery">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Gallery</h2></div>
      <div class="gal" role="group" aria-label="Gallery">
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/IMG_0115.webp" alt="Operating Room" loading="eager" fetchpriority="high" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0136.webp" alt="Patient Room" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0132.webp" alt="Staff Team" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0124.webp" alt="Patient Room" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/photo_2025-06-04_12-54-32.webp" alt="Operating Room" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--up">
          <figure><img src="/imaghosp/photo_2025-06-04_12-55-54.webp" alt="Staff Team" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0135_3_11zon.webp" alt="Laboratory" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0131.webp" alt="Reception Area" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0122.webp" alt="Laboratory" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/IMG_0113.webp" alt="Staff Team" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0134.webp" alt="Operating Room" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_0127.webp" alt="Hospital Lobby" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/photo_2025-06-04_12-53-17.webp" alt="Laboratory" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
      </div>
    </div>
  </section>

  <!-- REVIEWS. The existing Elfsight widget, this branch's own id, left
       exactly as it was found. Real Google reviews in the languages the
       patients actually wrote them in are the strongest proof on the
       page, so they sit above the map rather than below it. -->
  <section class="sec sec--tint" id="reviews">
    <div class="wrap wrap--wide">
      <script src="https://static.elfsight.com/platform/platform.js" async></script>
      <div class="elfsight-app-8cd24722-d38e-4257-9c69-83c4b04e104d" data-elfsight-app-lazy></div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="sec sec--tint" id="contact">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Contact &amp; Location</h2></div>
      <div class="cplace" data-reveal>
        <div class="cplace__map">
          <iframe title="Map showing MedPark Health Hub, Hurghada" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3552.440082274907!2d33.8596514!3d27.079416399999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x144d7f004f651d87%3A0x7bd0fbe33dc1c9a7!2sMedPark%20Health%20Hub!5e0!3m2!1sen!2seg!4v1788272094825!5m2!1sen!2seg"></iframe>
        </div>
        <div class="cplace__body">
          <div class="cplace__rows">
            <div class="cplace__row"><i class="fas fa-location-dot" aria-hidden="true"></i>
              <span><b>Address</b>Sahl Hasheesh Road, Hurghada, Red Sea</span></div>
            <div class="cplace__row"><i class="fas fa-phone" aria-hidden="true"></i>
              <span><b>Phone</b><a href="tel:+201222289383">+20 122 228 9383</a></span></div>
            <div class="cplace__row"><i class="fas fa-envelope" aria-hidden="true"></i>
              <span><b>Email</b><a href="mailto:info@medparkhospitals.com">info@medparkhospitals.com</a></span></div>
            <div class="cplace__row"><i class="fas fa-clock" aria-hidden="true"></i>
              <span><b>Working Hours</b>24/7 Emergency, 8:00 - 20:00 Outpatient</span></div>
          </div>
          <div class="cplace__cta">
            <a class="btn btn--urgent" href="tel:+201222289383"><i class="fas fa-phone" aria-hidden="true"></i> +20 122 228 9383</a>
            <a class="btn btn--outline" href="https://www.google.com/maps/dir/?api=1&amp;destination=27.0794164,33.8596514" target="_blank" rel="noopener">
              <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> Get directions</a>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/_footer.php'; ?>
