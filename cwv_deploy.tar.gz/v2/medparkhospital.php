<?php
/* MedPark v2: medparkhospital. DRAFT, served only on ?preview=2.

   Rebuilt from scratch 2026-09-05. Every word comes out of medparkhospital.php
   unchanged: the h1, the subtitle, the about paragraph, the nine service
   names, the gallery alt text, the contact rows, the map. The generator
   stops rather than inventing anything it cannot find.

   The page keeps its own assets throughout: its own hero photograph, its
   own video, and its own Google reviews widget id. Nothing is borrowed
   from the other branch or from the home page. */
$SITE = 'https://www.medparkhospitals.com';
$TEL  = '+201222710888';
$TELD = '+20 122 271 0888';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };

$nav = [
  '/' => 'Home', '/about/' => 'About', '/emergency-urgent-care/' => 'Emergency',
  '/services/' => 'Services', '/diagnostics-imaging/' => 'Diagnostics',
  '/news/' => 'News', '/contact-us/' => 'Contact',
];

$PAGE_TITLE = 'Hospital in El Quseir: 24/7 Emergency, ICU & CT | MedPark';
$PAGE_DESC  = 'MedPark Hospital in El Quseir: 24/7 emergency and urgent care, ICU, CT scan and laboratory, on the Red Sea coast. International insurance accepted.';
$PAGE_PATH  = '/medparkhospital.php';
$PAGE_LANG  = 'en';
$PAGE_HERO_PRELOAD = '/imaghosp/IMG_4655.webp';
$MP_CRUMBS  = array(
  'Home' => '/',
  'MedPark Hospital' => '/medparkhospital.php',
);
$MP_MEDICAL = true;
$MP_MAINENTITY = 'https://www.medparkhospitals.com/medparkhospital.php#hospital';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="loc-page">

  <!-- HERO. The page's own photograph. The phone number and the existing
       directions link sit here because somebody unwell on holiday needs
       to reach the hospital before they need to read about it. -->
  <section class="phero">
    <img class="phero__bg" src="/imaghosp/IMG_4655.webp" alt="" aria-hidden="true" fetchpriority="high" decoding="async" width="1410" height="1170">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <h1>MedPark Hospital El Quseir</h1>
      <p class="phero__lead">Exceptional Care in the Heart of the Red Sea</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201210533335">
          <i class="fas fa-phone" aria-hidden="true"></i> +20 121 053 3335</a>
        <a class="btn btn--ghost btn--lg" href="https://www.google.com/maps/dir/?api=1&amp;destination=26.1498769,34.2487632" target="_blank" rel="noopener">
          <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> Get directions</a>
      </div>
    </div>
  </section>

  <!-- AT A GLANCE. The same address and hours as the contact section,
       surfaced where somebody deciding whether to travel will look. -->
  <section class="glance">
    <div class="wrap">
      <div class="glance__card">
        <div class="glance__item">
          <i class="fas fa-location-dot" aria-hidden="true"></i>
          <div class="glance__text">
            <b>Address</b>
            <a href="https://maps.google.com/?cid=730530133612432340" target="_blank" rel="noopener">Al Owina, El Quseir, Red Sea Governorate, Egypt
              <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i></a>
          </div>
        </div>
        <div class="glance__item">
          <i class="fas fa-clock" aria-hidden="true"></i>
          <div class="glance__text">
            <b>Working Hours</b>
            <span>24/7 Emergency, 8:00 - 20:00 Outpatient</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ABOUT -->
  <section class="sec" id="about">
    <div class="wrap sec__narrow">
      <div class="sec-head" data-reveal><h2>About the Hospital</h2></div>
      <p class="prose" data-reveal><strong class="texthosp">MedPark Hospital</strong> in El Quseir is one of the largest multi-disciplinary specialty tertiary care hospitals in the Red Sea Governorate. It provides a full spectrum of inpatient and outpatient services, emergency care 24/7, and state-of-the-art medical, surgical, and diagnostic technology. Our dedicated team of medical professionals, nurses, and technologists ensures high-quality care built on compassion, respect, and integrity. Together, we are building a stronger, healthier future—saving lives, improving outcomes, and shaping the standard for healthcare in the Red Sea and beyond.</p>
    </div>
  </section>

  <!-- VIDEO. Two files where the page used to have one: a small silent
       loop behind the button, and the full-quality clip with sound that
       only downloads when somebody presses play. Both fall back to the
       original file if the re-encoded ones are not uploaded yet. The
       loop carries preload=none and does not start until it scrolls
       into view, so it costs nothing to anyone who never reaches it. -->
  <?php
    /* Prefer the re-encoded files, fall back to the original. */
    $mp_v     = '/videos/widget-1';
    $mp_root  = $_SERVER["DOCUMENT_ROOT"];
    $mp_prev  = is_file($mp_root . $mp_v . "-preview.mp4") ? $mp_v . "-preview.mp4" : $mp_v . ".mp4";
    $mp_hq    = is_file($mp_root . $mp_v . "-hq.mp4")      ? $mp_v . "-hq.mp4"      : $mp_v . ".mp4";
  ?>
  <section class="sec sec--dark" id="video">
    <div class="wrap">
      <div class="vshow" data-reveal>
        <video class="vshow__v" muted loop playsinline preload="none"
               data-lazyvideo="<?php echo $e($mp_prev); ?>"
               poster="/videos/widget-1.jpg" aria-hidden="true" tabindex="-1"></video>
        <button type="button" class="vshow__play" data-video-open data-video-fullscreen
                data-video-src="<?php echo $e($mp_hq); ?>"
                aria-label="Watch the video">
          <span class="vshow__ring"><i class="fas fa-play" aria-hidden="true"></i></span>
          <span class="vshow__label">Watch video</span>
        </button>
      </div>
    </div>
  </section>

  <!-- SERVICES. Each name carries its own icon, from the free Font
       Awesome set the site already loads. For a visitor skimming in a
       second language a tooth or a brain lands before the words do. -->
  <section class="sec" id="services">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Services Offered</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-user-doctor" aria-hidden="true"></i><span>General &amp; Family Medicine</span></li>
        <li class="svc"><i class="fas fa-truck-medical" aria-hidden="true"></i><span>Emergency &amp; Urgent Care</span></li>
        <li class="svc"><i class="fas fa-person-dress" aria-hidden="true"></i><span>Women’s Health</span></li>
        <li class="svc"><i class="fas fa-person" aria-hidden="true"></i><span>Men’s Health</span></li>
        <li class="svc"><i class="fas fa-brain" aria-hidden="true"></i><span>Mental Health &amp; Counseling</span></li>
        <li class="svc"><i class="fas fa-shield-heart" aria-hidden="true"></i><span>Wellness &amp; Preventive Medicine</span></li>
        <li class="svc"><i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i><span>Aesthetics &amp; Skin Care</span></li>
        <li class="svc"><i class="fas fa-tooth" aria-hidden="true"></i><span>Dental Services</span></li>
        <li class="svc"><i class="fas fa-flask-vial" aria-hidden="true"></i><span>Laboratory &amp; Diagnostics</span></li>
      </ul>
    </div>
  </section>

  <!-- GALLERY. A vertical marquee: three columns drifting in opposite
       directions, cloned once in JavaScript so the loop is seamless.
       Pauses on hover and focus, and does not run at all under
       prefers-reduced-motion. Replaces the Swiper bundle: a
       render-blocking stylesheet plus a script from unpkg. -->
  <section class="sec sec--tint" id="gallery">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Gallery</h2></div>
      <div class="gal" role="group" aria-label="Gallery">
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/Polarasmy-110.webp" alt="Patient Room" loading="eager" fetchpriority="high" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4651.webp" alt="Operating Room" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4656.webp" alt="Hospital Lobby" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-185.webp" alt="Operating Room" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--up">
          <figure><img src="/imaghosp/IMG_4647.webp" alt="Patient Room" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4650.webp" alt="Staff Team" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-182.webp" alt="Patient Room" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
        <div class="gal__col gal__col--down">
          <figure><img src="/imaghosp/IMG_4653.webp" alt="Laboratory" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/IMG_4646.webp" alt="Reception Area" loading="lazy" decoding="async" width="640" height="800"></figure>
          <figure><img src="/imaghosp/Polarasmy-183.webp" alt="Laboratory" loading="lazy" decoding="async" width="640" height="800"></figure>
        </div>
      </div>
    </div>
  </section>

  <!-- REVIEWS. The existing Elfsight widget, this branch's own id, left
       exactly as it was found. Real Google reviews in the languages the
       patients actually wrote them in are the strongest proof on the
       page, so they sit above the map rather than below it. -->
  <section class="sec sec--tint" id="reviews">
    <div class="wrap wrap--wide">
      <script src="https://static.elfsight.com/platform/platform.js" async></script>
      <div class="elfsight-app-7a31d17b-c9b4-414b-8728-4690aee2f8be" data-elfsight-app-lazy></div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="sec sec--tint" id="contact">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Contact &amp; Location</h2></div>
      <div class="cplace" data-reveal>
        <div class="cplace__map">
          <iframe title="Map showing MedPark Hospital, El Quseir" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3581.437519306275!2d34.24876319999999!3d26.1498769!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x144cc5fcda48bd71%3A0xa235d4937b00bd4!2sMedpark%20Hospital!5e0!3m2!1sen!2seg!4v1788272123211!5m2!1sen!2seg"></iframe>
        </div>
        <div class="cplace__body">
          <div class="cplace__rows">
            <div class="cplace__row"><i class="fas fa-location-dot" aria-hidden="true"></i>
              <span><b>Address</b>Al Owina, El Quseir, Red Sea Governorate, Egypt</span></div>
            <div class="cplace__row"><i class="fas fa-phone" aria-hidden="true"></i>
              <span><b>Phone</b><a href="tel:+201210533335">+20 121 053 3335</a></span></div>
            <div class="cplace__row"><i class="fas fa-envelope" aria-hidden="true"></i>
              <span><b>Email</b><a href="mailto:info@medparkhospitals.com">info@medparkhospitals.com</a></span></div>
            <div class="cplace__row"><i class="fas fa-clock" aria-hidden="true"></i>
              <span><b>Working Hours</b>24/7 Emergency, 8:00 - 20:00 Outpatient</span></div>
          </div>
          <div class="cplace__cta">
            <a class="btn btn--urgent" href="tel:+201210533335"><i class="fas fa-phone" aria-hidden="true"></i> +20 121 053 3335</a>
            <a class="btn btn--outline" href="https://www.google.com/maps/dir/?api=1&amp;destination=26.1498769,34.2487632" target="_blank" rel="noopener">
              <i class="fas fa-diamond-turn-right" aria-hidden="true"></i> Get directions</a>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/_footer.php'; ?>
