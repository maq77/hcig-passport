<?php
/* MedPark v2: emergency-urgent-care. DRAFT, served only on ?preview=2.

   Built 2026-09-05. Every word on this page comes out of
   emergency-urgent-care/index.php unchanged: the h1, the lead paragraph, each
   section heading, each card title and description, the call to action and
   its button labels. The generator stops rather than invent anything it
   cannot find in the source.

   This page keeps the photograph it already used. */
$SITE = 'https://www.medparkhospitals.com';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };

$PAGE_TITLE = '24/7 Emergency & Urgent Care, Red Sea | MedPark Hospital';
$PAGE_DESC  = '24/7 emergency and urgent care at MedPark: fast diagnostics, CT scan, ICU support and ambulance across Hurghada, Sahl Hasheesh and El Quseir.';
$PAGE_PATH  = '/emergency-urgent-care/';
$PAGE_LANG  = 'en';
$MP_CRUMBS  = array(
  'Home' => '/',
  'Emergency & Urgent Care' => '/emergency-urgent-care/',
);
$MP_MEDICAL = true;
$PAGE_HERO_PRELOAD = '/img/emergenc.jpg';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="svc-page">

  <!-- HERO. The page's own photograph, its own h1 and its own lead
       paragraph. The emergency number sits in the hero because somebody
       reading this page may need to call before they finish reading. -->
  <section class="phero">
    <img class="phero__bg" src="/img/emergenc.jpg" alt="" aria-hidden="true" fetchpriority="high" decoding="async">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <nav class="crumbs" aria-label="Breadcrumb">
        <a href="/">Home</a> <span aria-hidden="true">&rsaquo;</span> <span>24/7 Emergency &amp; Urgent Care at MedPark Hospital</span>
      </nav>
      <h1>24/7 Emergency &amp; Urgent Care at MedPark Hospital</h1>
      <p class="phero__lead">MedPark Hospital provides 24/7 emergency and urgent care services for patients who need immediate medical attention, fast diagnostics, and hospital-based support.</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Call Now</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>When to come here</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-heartbeat" aria-hidden="true"></i><span>Chest pain</span></li>
        <li class="svc"><i class="fas fa-lungs" aria-hidden="true"></i><span>Breathing difficulty</span></li>
        <li class="svc"><i class="fas fa-bolt" aria-hidden="true"></i><span>Severe pain</span></li>
        <li class="svc"><i class="fas fa-tint" aria-hidden="true"></i><span>Dehydration</span></li>
        <li class="svc"><i class="fas fa-user-injured" aria-hidden="true"></i><span>Trauma / Injury</span></li>
        <li class="svc"><i class="fas fa-thermometer-half" aria-hidden="true"></i><span>Fever &amp; Infection</span></li>
        <li class="svc"><i class="fas fa-person-circle-exclamation" aria-hidden="true"></i><span>Acute abdominal pain</span></li>
        <li class="svc"><i class="fas fa-dizzy" aria-hidden="true"></i><span>Weakness / Dizziness</span></li>
      </ul>
    </div>
  </section>

  <section class="sec">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>What MedPark Hospital offers</h2></div>
      <ul class="feat__grid" data-reveal-stagger role="list">
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-kit-medical" aria-hidden="true"></i></span>
          <h3 class="feat__t">Emergency Department</h3>
          <p class="feat__d">Immediate medical evaluation and treatment for acute and life-threatening conditions.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-user-doctor" aria-hidden="true"></i></span>
          <h3 class="feat__t">Urgent Care</h3>
          <p class="feat__d">Fast treatment for injuries, infections, dehydration, and non-life-threatening urgent medical issues.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-x-ray" aria-hidden="true"></i></span>
          <h3 class="feat__t">CT Scan &amp; Imaging</h3>
          <p class="feat__d">Rapid CT imaging and diagnostic support for accurate and timely clinical decisions.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-heart-pulse" aria-hidden="true"></i></span>
          <h3 class="feat__t">ICU / Critical Care</h3>
          <p class="feat__d">Advanced monitoring and intensive treatment for patients with serious medical conditions.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-truck-medical" aria-hidden="true"></i></span>
          <h3 class="feat__t">Ambulance Support</h3>
          <p class="feat__d">Emergency ambulance coordination and patient transfer across Hurghada, El Quseir, and the Red Sea region.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-vials" aria-hidden="true"></i></span>
          <h3 class="feat__t">Laboratory &amp; Diagnostics</h3>
          <p class="feat__d">Comprehensive laboratory testing and diagnostic services supporting rapid diagnosis and treatment.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-bed-pulse" aria-hidden="true"></i></span>
          <h3 class="feat__t">Inpatient / Hospital Admission</h3>
          <p class="feat__d">Hospital admission and monitoring available when advanced treatment or observation is required.</p>
        </li>
      </ul>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>For tourists and international patients</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-language" aria-hidden="true"></i><span>Multilingual support</span></li>
        <li class="svc"><i class="fas fa-file-medical" aria-hidden="true"></i><span>Insurance assistance</span></li>
        <li class="svc"><i class="fas fa-clock" aria-hidden="true"></i><span>Quick coordination</span></li>
        <li class="svc"><i class="fas fa-hotel" aria-hidden="true"></i><span>Hotel / transfer communication</span></li>
      </ul>
      <p class="feat__note">Cashless treatment available through international insurance and assistance networks.</p>
    </div>
  </section>

  <!-- CALL TO ACTION. The same heading and the same buttons the live
       page carries, in the same colours. Red is the emergency action
       and green is WhatsApp: both are safety-critical, not decoration. -->
  <section class="sec ctaband">
    <div class="wrap ctaband__inner">
      <h2 class="ctaband__h">Call MedPark Hospital Emergency Team</h2>
      <div class="ctaband__actions">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Call Now</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>
</main>
<?php include __DIR__ . '/_footer.php'; ?>
