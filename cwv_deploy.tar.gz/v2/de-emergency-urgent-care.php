<?php
/* MedPark v2, /de/notfall-und-ukutversorgung/. Built 2026-09-05.

   Every word comes out of this page's own DE source: the h1, the lead,
   each heading, each card and the call to action. Nothing translated. */
$SITE = 'https://www.medparkhospitals.com';
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };
$PAGE_TITLE = '24/7 Notfall- und Akutversorgung | MedPark Hospital';
$PAGE_DESC  = '24/7 emergency and urgent care at MedPark Hospital. Fast diagnostics, ICU support, ambulance services, and hospital-based treatment in Hurghada, El Quseir and the Red Sea region.';
$PAGE_PATH  = '/de/notfall-und-ukutversorgung/';
$PAGE_LANG  = 'de';
$MP_MEDICAL = true;
$MP_CRUMBS  = array(
  'MedPark' => '/de/',
  '24/7 Notfall- und Akutversorgung bei MedPark' => '/de/notfall-und-ukutversorgung/',
);
$PAGE_HERO_PRELOAD = '/img/emergenc.jpg';
include __DIR__ . '/_head.php';
include __DIR__ . '/_header.php';
?>
<main id="main" class="svc-page">

  <section class="phero">
    <img class="phero__bg" src="/img/emergenc.jpg" alt="" aria-hidden="true" fetchpriority="high" decoding="async">
    <div class="phero__scrim"></div>
    <div class="wrap phero__inner">
      <nav class="crumbs" aria-label="Breadcrumb">
        <a href="/de/">MedPark</a> <span aria-hidden="true">&rsaquo;</span> <span>24/7 Notfall- und Akutversorgung bei MedPark</span>
      </nav>
      <h1>24/7 Notfall- und Akutversorgung bei MedPark</h1>
      <p class="phero__lead">Das MedPark Hospital bietet rund um die Uhr Notfall- und Akutversorgung für Patienten, die sofortige medizinische Betreuung, schnelle Diagnostik und stationäre Unterstützung benötigen.</p>
      <div class="phero__cta">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Jetzt anrufen</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Wann Sie hierher kommen sollten</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-heartbeat" aria-hidden="true"></i><span>Brustschmerzen</span></li>
        <li class="svc"><i class="fas fa-lungs" aria-hidden="true"></i><span>Atembeschwerden</span></li>
        <li class="svc"><i class="fas fa-bolt" aria-hidden="true"></i><span>Starke Schmerzen</span></li>
        <li class="svc"><i class="fas fa-tint" aria-hidden="true"></i><span>Dehydration</span></li>
        <li class="svc"><i class="fas fa-user-injured" aria-hidden="true"></i><span>Trauma / Verletzung</span></li>
        <li class="svc"><i class="fas fa-thermometer-half" aria-hidden="true"></i><span>Fieber &amp; Infektion</span></li>
        <li class="svc"><i class="fas fa-circle-check" aria-hidden="true"></i><span>Akute Bauchschmerzen</span></li>
        <li class="svc"><i class="fas fa-dizzy" aria-hidden="true"></i><span>Schwäche / Schwindel</span></li>
      </ul>
    </div>
  </section>

  <section class="sec">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Was das MedPark Hospital bietet</h2></div>
      <ul class="feat__grid" data-reveal-stagger role="list">
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Notaufnahme</h3>
          <p class="feat__d">Sofortige medizinische Untersuchung und Behandlung bei akuten und lebensbedrohlichen Zuständen.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Akutversorgung</h3>
          <p class="feat__d">Schnelle Behandlung von Verletzungen, Infektionen, Dehydration und nicht lebensbedrohlichen dringenden medizinischen Problemen.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">CT-Scan &amp; Bildgebung</h3>
          <p class="feat__d">Schnelle CT-Bildgebung und diagnostische Unterstützung für präzise und zeitgerechte klinische Entscheidungen.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Intensivstation / Critical Care</h3>
          <p class="feat__d">Erweiterte Überwachung und intensive Behandlung für Patienten mit schweren medizinischen Zuständen.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Krankentransport &amp; Ambulanz</h3>
          <p class="feat__d">Koordination von Notfall-Transporten und Patientenüberführungen in Hurghada, El Quseir und der gesamten Region am Roten Meer.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Labor &amp; Diagnostik</h3>
          <p class="feat__d">Umfassende Laboruntersuchungen und diagnostische Leistungen zur schnellen Diagnose und Behandlung.</p>
        </li>
        <li class="feat">
          <span class="feat__ico"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
          <h3 class="feat__t">Stationäre Aufnahme</h3>
          <p class="feat__d">Krankenhausaufnahme und Überwachung, wenn eine erweiterte Behandlung oder Beobachtung erforderlich ist.</p>
        </li>
      </ul>
    </div>
  </section>

  <section class="sec sec--tint">
    <div class="wrap">
      <div class="sec-head center" data-reveal><h2>Für Touristen und internationale Patienten</h2></div>
      <ul class="svc__grid svc__grid--ico" data-reveal-stagger role="list">
        <li class="svc"><i class="fas fa-language" aria-hidden="true"></i><span>Mehrsprachige Unterstützung</span></li>
        <li class="svc"><i class="fas fa-file-medical" aria-hidden="true"></i><span>Versicherungsunterstützung</span></li>
        <li class="svc"><i class="fas fa-clock" aria-hidden="true"></i><span>Schnelle Koordination</span></li>
        <li class="svc"><i class="fas fa-hotel" aria-hidden="true"></i><span>Kommunikation mit Hotel / Transfer</span></li>
      </ul>
      <p class="feat__note">Bargeldlose Behandlung über internationale Versicherungs- und Assistance-Netzwerke verfügbar.</p>
    </div>
  </section>

  <section class="sec ctaband">
    <div class="wrap ctaband__inner">
      <h2 class="ctaband__h">Rufen Sie das MedPark-Notfallteam an</h2>
      <div class="ctaband__actions">
        <a class="btn btn--urgent btn--lg" href="tel:+201222710888">
          <i class="fas fa-phone" aria-hidden="true"></i> Jetzt anrufen</a>
        <a class="btn btn--wa btn--lg" href="https://wa.me/201222710888" target="_blank" rel="noopener">
          <i class="fab fa-whatsapp" aria-hidden="true"></i> Message us on WhatsApp</a>
      </div>
    </div>
  </section>

</main>
<?php include __DIR__ . '/_footer.php'; ?>
