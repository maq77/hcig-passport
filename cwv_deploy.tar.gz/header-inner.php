<?php
// Cache-bust: assets carry a 1-year immutable Cache-Control (see .htaccess), so a
// changed stylesheet is never re-fetched by a browser that already has it.
// Appending the file's mtime gives each edit a fresh URL. Added 2026-09-01 after
// a CSS fix appeared not to work purely because of a stale cache.
if (!function_exists('mp_asset')) {
  function mp_asset($path) {
    $abs = $_SERVER['DOCUMENT_ROOT'] . $path;
    return $path . (is_file($abs) ? '?v=' . filemtime($abs) : '');
  }
}
?>
<?php
// ---------------------------------------------------------------------------
// Page meta. A page sets these variables before including this file. The
// fallbacks make sure a page that forgets still ships a valid title,
// description and canonical.
//
// Added 2026-09-01. Before this, the file emitted no title, no description and
// no canonical, which is why several live pages had none at all.
//
//   $page_title  string
//   $page_desc   string
//   $page_path   string, e.g. '/healthhub.php' (defaults to the request path)
//   $page_lang   'en' | 'de' | 'pl'
//   $page_alts   array('en' => '/x/', 'de' => '/de/x/', 'pl' => '/pl/x/')
// ---------------------------------------------------------------------------
// NOTE: title and description are emitted ONLY when the page sets them.
// Several pages in this codebase declare their own <title> in a second <head>
// block after this include. Emitting a default here would give those pages two
// title tags, and Google would use ours instead of theirs. So: opt in.
$SITE = 'https://www.medparkhospitals.com';
if (!isset($page_path))  $page_path  = strtok($_SERVER['REQUEST_URI'], '?');
if (!isset($page_lang))  $page_lang  = 'en';
if (!isset($og_image))   $og_image   = $SITE . '/logo.JPG';
if (!isset($page_alts))  $page_alts  = array();
$canonical = $SITE . $page_path;
$e = function ($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); };
?>
<!DOCTYPE html>
<html lang="<?php echo $e($page_lang); ?>">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<?php if (isset($page_title)): ?>
  <title><?php echo $e($page_title); ?></title>
<?php endif; ?>
<?php if (isset($page_desc)): ?>
  <meta name="description" content="<?php echo $e($page_desc); ?>" />
<?php endif; ?>
<?php if (isset($page_keywords)): ?>
  <meta name="keywords" content="<?php echo $e($page_keywords); ?>" />
<?php endif; ?>
  <meta name="author" content="MedPark Health Group" />
  <link rel="canonical" href="<?php echo $e($canonical); ?>" />

  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="MedPark Health Group" />
<?php if (isset($page_title)): ?>
  <meta property="og:title" content="<?php echo $e($page_title); ?>" />
<?php endif; ?>
<?php if (isset($page_desc)): ?>
  <meta property="og:description" content="<?php echo $e($page_desc); ?>" />
<?php endif; ?>
  <meta property="og:url" content="<?php echo $e($canonical); ?>" />
  <meta property="og:image" content="<?php echo $e($og_image); ?>" />
  <meta name="twitter:card" content="summary_large_image" />

<?php /* Article and breadcrumb structured data, emitted only for pages that set
   $mp_article. This is what lets a news post appear as a rich result and, more
   importantly here, what gives an AI assistant a clean, attributable statement
   of who published what and when. Without it an article is just prose an
   assistant has to guess at. Added 2026-09-03. */ ?>
<?php if (isset($mp_article) && is_array($mp_article)):
        $mp_img = !empty($mp_article['image']) ? $SITE . $mp_article['image'] : $og_image;
        $mp_pub = !empty($mp_article['date']) ? date('Y-m-d', (int)strtotime($mp_article['date'])) : '';
        $mp_ld = array(
          '@context' => 'https://schema.org',
          '@graph' => array(
            array(
              '@type' => 'NewsArticle',
              'headline' => $mp_article['headline'] ?? ($page_title ?? ''),
              'description' => $page_desc ?? '',
              'image' => array($mp_img),
              'inLanguage' => $page_lang,
              'mainEntityOfPage' => array('@type' => 'WebPage', '@id' => $canonical),
              'author' => array('@type' => 'Organization', 'name' => 'MedPark Health Group', 'url' => $SITE),
              'publisher' => array(
                '@type' => 'Organization',
                'name' => 'MedPark Health Group',
                'logo' => array('@type' => 'ImageObject', 'url' => $SITE . '/logo.JPG'),
              ),
            ),
            array(
              '@type' => 'BreadcrumbList',
              'itemListElement' => array(
                array('@type'=>'ListItem', 'position'=>1, 'name'=>'Home', 'item'=>$SITE . '/'),
                array('@type'=>'ListItem', 'position'=>2, 'name'=>'News', 'item'=>$SITE . '/news/'),
                array('@type'=>'ListItem', 'position'=>3, 'name'=>$mp_article['headline'] ?? ''),
              ),
            ),
          ),
        );
        if ($mp_pub !== '') { $mp_ld['@graph'][0]['datePublished'] = $mp_pub; }
?>
  <script type="application/ld+json"><?php
    echo json_encode($mp_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
  ?></script>
<?php endif; ?>
<?php /* Page-level structured data. See the note in the file header: this is
   what attaches a page to the MedPark entity and gives it a place in the site.
   Emitted for any page that sets $mp_crumbs, and never for news articles, which
   already emit their own NewsArticle graph above. */ ?>
<?php if (isset($mp_crumbs) && is_array($mp_crumbs) && !isset($mp_article)):
        $mp_items = array();
        $mp_pos = 0;
        foreach ($mp_crumbs as $mp_name => $mp_href) {
          $mp_pos++;
          $mp_it = array('@type' => 'ListItem', 'position' => $mp_pos, 'name' => $mp_name);
          if ($mp_href !== '') { $mp_it['item'] = $SITE . $mp_href; }
          $mp_items[] = $mp_it;
        }
        $mp_type = !empty($mp_medical) ? 'MedicalWebPage' : 'WebPage';
        $mp_node = array(
          '@type' => $mp_type,
          '@id' => $canonical . '#webpage',
          'url' => $canonical,
          'inLanguage' => $page_lang,
          'isPartOf' => array('@id' => $SITE . '/#website'),
          'about' => array('@id' => $SITE . '/#organization'),
          'publisher' => array('@id' => $SITE . '/#organization'),
        );
        if (isset($page_title)) { $mp_node['name'] = $page_title; }
        if (isset($page_desc))  { $mp_node['description'] = $page_desc; }
        if (isset($mp_primary)) { $mp_node['primaryImageOfPage'] = array('@type'=>'ImageObject','url'=>$SITE . $mp_primary); }
        /* A location page is about one facility. Pointing mainEntity at the
           @id already declared on the home page joins the two records instead
           of describing the same hospital twice in two different ways. */
        if (isset($mp_mainentity)) { $mp_node['mainEntity'] = array('@id' => $mp_mainentity); }
        $mp_graph = array(
          $mp_node,
          array(
            '@type' => 'BreadcrumbList',
            '@id' => $canonical . '#breadcrumb',
            'itemListElement' => $mp_items,
          ),
          array(
            '@type' => 'WebSite',
            '@id' => $SITE . '/#website',
            'url' => $SITE . '/',
            'name' => 'MedPark Health Group',
            'inLanguage' => $page_lang,
            'publisher' => array('@id' => $SITE . '/#organization'),
          ),
          array(
            '@type' => 'MedicalOrganization',
            '@id' => $SITE . '/#organization',
            'name' => 'MedPark Health Group',
            'url' => $SITE . '/',
            'logo' => $SITE . '/logo.JPG',
          ),
        );
        if (!empty($mp_extra_nodes) && is_array($mp_extra_nodes)) {
          foreach ($mp_extra_nodes as $mp_x) { $mp_graph[] = $mp_x; }
        }
?>
  <script type="application/ld+json"><?php
    echo json_encode(array('@context' => 'https://schema.org', '@graph' => $mp_graph),
                     JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
  ?></script>
<?php endif; ?>

<?php /* Page-supplied alternates win. When a page sets none, which is every
         page today, fall back to the verified central map. Before this fallback
         existed the loop below simply produced nothing. Added 2026-09-02. */ ?>
<?php if (!empty($page_alts)): ?>
<?php   foreach ($page_alts as $alt_lang => $alt_href): ?>
  <link rel="alternate" hreflang="<?php echo $e($alt_lang); ?>" href="<?php echo $e($SITE . $alt_href); ?>" />
<?php   endforeach; ?>
  <link rel="alternate" hreflang="x-default" href="<?php echo $e($SITE . reset($page_alts)); ?>" />
<?php else: ?>
<?php   require_once __DIR__ . '/hreflang.php'; mp_hreflang_tags(); ?>
<?php endif; ?>

    <link rel="stylesheet" href="<?php echo mp_asset('/css/styles.css'); ?>">
    <!-- 2026-09-01: was ../css/responsive.css, which resolves to /css/responsive.css
         from every subdirectory and 404s. Inner pages had no responsive CSS at all. -->
    <link rel="stylesheet" href="<?php echo mp_asset('/responsive.css'); ?>">
    <?php if (isset($mp_preload_hero)): ?>
  <link rel="preload" as="image" href="<?php echo $e($mp_preload_hero); ?>" fetchpriority="high">
<?php endif; ?>
    <!-- Mobile-first corrections. Must load last so it can override the legacy sheets. -->
    <link rel="stylesheet" href="<?php echo mp_asset('/css/mobile-first.css'); ?>">
<?php /* NEW DESIGN, DRAFT ONLY. Not live until approved.
         Preview with ?preview=1 on any URL. Remove this guard to go live. */ ?>
<?php if (isset($_GET['preview'])): ?>
    <link rel="preload" href="/fonts/Organo-Regular.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="<?php echo mp_asset('/css/brand.css'); ?>">
    <meta name="robots" content="noindex,nofollow">
<?php endif; ?>

<?php /* Font Awesome, loaded without blocking the render. It was previously a
   render-blocking request in the critical path, and on the home page it was
   requested twice. Icons now paint a moment after the text, which is the
   correct trade for a page most visitors open on hotel wifi. */ ?>
  <?php /* Icons, 2026-09-08. Was the whole Font Awesome set from a CDN, 267 KB of
     webfont and 100 KB of stylesheet, to draw the icons this site actually uses.
     This is the same font cut down to those, on our own domain, so it also drops
     a DNS lookup and a TLS handshake to a third party. Class names unchanged.
     Rebuild with scratchpad/fa/build_fa.py after adding any new icon. */ ?>
  <link rel="preload" href="/fonts/mp-icons-solid.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="preload" href="/fonts/mp-icons-brands.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="/css/mp-icons.css?v=<?php echo @filemtime($_SERVER['DOCUMENT_ROOT'].'/css/mp-icons.css'); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arimo:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
<!-- Google tag (gtag.js) -->
<?php /* GA4, one property, ours. G-QSK7TQV4S0 was created by a previous
   developer and nobody here can reach it. Keeping it alongside ours made Google
   fetch a second config bundle, 167 KB on every first visit, for data no one can
   read. Removed 2026-09-08. */ ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-LE2B44N7SF"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  /* Second property, added 2026-09-05. The first was created by a
     previous developer and nobody here can reach it; this one is ours.
     Both receive the same hits from the one library above. */
  gtag('config', 'G-LE2B44N7SF');
</script>
<meta name="yandex-verification" content="44a6d356f17795bd" />
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function(m,e,t,r,i,k,a){
        m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
        m[i].l=1*new Date();
        for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
        k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)
    })(window, document,'script','https://mc.yandex.ru/metrika/tag.js?id=110789001', 'ym');

    ym(110789001, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/110789001" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<?php /* Site navigation, declared for sitelinks. See sitenav.php. */
      require_once __DIR__ . '/sitenav.php';
      mp_sitenav_tags($page_lang); ?>
<link rel="icon" href="/logo.JPG">
</head>
<body>




<!-- header-inner.php -->
<header class="med-header static-header">
  <div class="med-container">
    <div class="med-header-inner" style="display: flex; align-items: center; justify-content: space-between;">
      
      <!-- Logo -->
      <div class="med-logo">
        <a href="/"><img src="../../logo.JPG" alt="MedPark Logo" /></a>
      </div>

      <!-- Desktop Menu -->
      <nav class="med-nav">
        <a href="/">Home</a>
        <a href="/about/">About</a>
        <a href="/emergency-urgent-care/">Emergency & Urgent Care</a>
        <a href="/services/">Services</a>
        <a href="/diagnostics-imaging/">Diagnostics</a>
        <a href="/news/">News</a>
        <a href="/contact-us/">Contact</a>
      </nav>

      <!-- Desktop Buttons -->
      <div class="med-header-buttons">
        <a href="/de/" class="med-lang-btn">DE</a>
        <a href="/pl/" class="med-lang-btn">PL</a> 
        <a href="/feedback.php" class="med-btn-transparent med-btn-header">Book Appointment</a>
        <a href="tel:+201222710888" class="med-btn">Call</a>
      </div>

      <!-- Burger Button -->
      <button class="burger-btn" id="burger-toggle">&#9776;</button>
    </div>
  </div>

  <!-- Mobile Menu -->
  <div class="mobile-menu" id="mobileMenu">
    <nav class="mobile-nav">
      <a href="/">Home</a>
      <a href="/about/">About</a>
      <a href="/emergency-urgent-care/">Emergency & Urgent Care</a>
      <a href="/services/">Services</a>
      <a href="/diagnostics-imaging/">Diagnostics</a>
      <a href="/news/">News</a>
      <a href="/contact-us/">Contact</a>
    </nav>

<div class="mobile-actions">
  <div class="mobile-buttons">
    <a href="/de/" class="med-lang-btn">DE</a>
    <a href="/pl/" class="med-lang-btn">PL</a> 
    <a href="/feedback.php" class="med-btn med-btn-header">Book Appointment</a>
   <a href="tel:+201222710888" class="med-btn">Call</a>
  </div>

  <div class="mobile-hospitals-contact">
    <p><a href="tel:+201222710888">+20 122 271 0888</a></p>
    <p><a href="mailto:info@medparkhospitals.com">info@medparkhospitals.com</a></p>
  </div>
</div>
  </div>

  <!-- Schema.org JSON-LD (без изменений) -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "MedPark Health Group",
    "url": "https://medparkhospitals.com/",
    "logo": "https://medparkhospitals.com/logo.JPG",
    "description": "MedPark Health Group was established in 2018 and has since become a key player in Egypt’s Red Sea region. We offer 24/7 care in our two modern facilities — in Hurghada and El Quseir.",
    "email": "info@medparkhospitals.com"
  }
  </script>
</header>

